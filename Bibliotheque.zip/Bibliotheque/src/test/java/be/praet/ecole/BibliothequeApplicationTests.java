package be.praet.ecole;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BibliothequeApplicationTests {

	@Test
	void contextLoads() {
	}

}
