package be.praet.biblio.repos;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import be.praet.biblio.models.Avis;

public interface AvisRep extends CrudRepository<Avis, Long>{

	@Query(value="SELECT CAST(COUNT(1) AS BIT) FROM avis \n" + 
			"WHERE idUtilisateur = ?1 AND idLivre = ?2", nativeQuery=true)
	boolean exist(long idUtilisateur, long idLivre);
	
	@Query(value="SELECT CAST(COUNT(1) AS BIT) FROM location\n" + 
			"INNER JOIN exemplaire ON [location].idExemplaire = exemplaire.id\n" + 
			"INNER JOIN livre ON exemplaire.idLivre = livre.id\n" + 
			"WHERE idUtilisateur = ?1 AND livre.id = ?2", nativeQuery=true)
	boolean isAuthorized(long idUtilisateur, long idLivre);
}
