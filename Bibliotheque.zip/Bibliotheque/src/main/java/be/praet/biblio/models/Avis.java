package be.praet.biblio.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="avis")
public class Avis {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id", nullable=false)
	private long id;
	@Column(name="note", nullable=false)
	private long note;
	@Column(name="commentaire", nullable=false)
	private String commentaire;
	@Column(name="idutilisateur", nullable=false)
	private long idUtilisateur;
	@Column(name="idlivre", nullable=false)
	private long idLivre;
	public Avis() {
		super();
	}
	public Avis(long note, String commentaire, long idUtilisateur, long idLivre) {
		super();
		this.note = note;
		this.commentaire = commentaire;
		this.idUtilisateur = idUtilisateur;
		this.idLivre = idLivre;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public long getNote() {
		return note;
	}
	public void setNote(long note) {
		this.note = note;
	}
	public String getCommentaire() {
		return commentaire;
	}
	public void setCommentaire(String commentaire) {
		this.commentaire = commentaire;
	}
	public long getIdUtilisateur() {
		return idUtilisateur;
	}
	public void setIdUtilisateur(long idUtilisateur) {
		this.idUtilisateur = idUtilisateur;
	}
	public long getIdLivre() {
		return idLivre;
	}
	public void setIdLivre(long idLivre) {
		this.idLivre = idLivre;
	}
	
	
	
}
