package be.praet.biblio.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="bibliotheque")
public class Bibliotheque {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id", nullable=false)
	private long id;
	@Column(name="nom", nullable=false)
	private String nom;
	@Column(name="adresse", nullable=false)
	private String adresse;
	@Column(name="telephone", nullable=false)
	private String telephone;
	@Column(name="email", nullable=false)
	private String email;
	@Column(name="web")
	private String web;
	@Column(name="description")
	private String description;
	@Column(name="amendemontant", nullable=false)
	private float amendeMontant;
	@Column(name="cotisationprix", nullable=false)
	private float cotisation;
	@Column(name="nblocationmax", nullable=false)
	private int nbLocation;
	@Column(name="dureepret", nullable=false)
	private int dureePret;
	
	public Bibliotheque() {
		super();
	}

	public Bibliotheque(long id, String nom, String adresse, String telephone, String email, String web,
			String description, float amendeMontant, float cotisation, int nbLocation, int dureePret) {
		super();
		this.id = id;
		this.nom = nom;
		this.adresse = adresse;
		this.telephone = telephone;
		this.email = email;
		this.web = web;
		this.description = description;
		this.amendeMontant = amendeMontant;
		this.cotisation = cotisation;
		this.nbLocation = nbLocation;
		this.dureePret = dureePret;
	}
	
	public Bibliotheque(String nom, String adresse, String telephone, String email, String web,
			String description, float amendeMontant, float cotisation, int nbLocation, int dureePret) {
		super();
		this.nom = nom;
		this.adresse = adresse;
		this.telephone = telephone;
		this.email = email;
		this.web = web;
		this.description = description;
		this.amendeMontant = amendeMontant;
		this.cotisation = cotisation;
		this.nbLocation = nbLocation;
		this.dureePret = dureePret;
	}
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public String getAdresse() {
		return adresse;
	}
	public void setAdresse(String adresse) {
		this.adresse = adresse;
	}
	public String getTelephone() {
		return telephone;
	}
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getWeb() {
		return web;
	}
	public void setWeb(String web) {
		this.web = web;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public float getAmendeMontant() {
		return amendeMontant;
	}
	public void setPrixAmende(float amendeMontant) {
		this.amendeMontant = amendeMontant;
	}
	public float getCotisation() {
		return cotisation;
	}
	public void setCotisation(float cotisation) {
		this.cotisation = cotisation;
	}
	public int getNbLocation() {
		return nbLocation;
	}
	public void setNbLocation(int nbLocation) {
		this.nbLocation = nbLocation;
	}
	public int getDureePret() {
		return dureePret;
	}
	public void setDureePret(int dureePret) {
		this.dureePret = dureePret;
	}
	
	
}
