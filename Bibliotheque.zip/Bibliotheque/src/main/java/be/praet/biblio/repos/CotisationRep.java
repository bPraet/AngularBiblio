package be.praet.biblio.repos;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import be.praet.biblio.models.Cotisation;

public interface CotisationRep extends CrudRepository<Cotisation, Long>{
	
	@Query(value="SELECT TOP 1 * FROM cotisation WHERE idUtilisateur = ?1\n" + 
			"AND idBibliotheque = ?2 AND DATEADD(YEAR, 1, date) >= GETDATE()", nativeQuery=true)
	Cotisation getCotisationById(long idUtilisateur, long idBibliotheque);
}
