package be.praet.biblio.repos;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import be.praet.biblio.models.Bibliotheque;

public interface BibliothequeRep extends CrudRepository<Bibliotheque, Long>{
	@Query(value="SELECT bibliotheque.* FROM bibliotheque\n" + 
			"INNER JOIN responsable ON bibliotheque.id = responsable.idBibliotheque\n" + 
			"WHERE responsable.idAdministrateur = ?1 AND isDeleted != 1", nativeQuery=true)
	List<Bibliotheque> getBibliotheques(long idAdmin);

	@Query(value="SELECT * FROM bibliotheque\n" +
			"WHERE isDeleted != 1", nativeQuery=true)
	List<Bibliotheque> getBibliotheques();
	
	@Query(value="SELECT * FROM bibliotheque\n" +
			"WHERE id = ?1 AND isDeleted != 1", nativeQuery=true)
	Bibliotheque getBibliotheque(long id);
	
	@Query(value="SELECT idBibliotheque FROM responsable\n" + 
			"WHERE idAdministrateur = ?1", nativeQuery=true)
	List<Long> getBibliothequeIdByAdmin(long idAdmin);
	
	@Query(value="SELECT id FROM bibliotheque", nativeQuery=true)
	List<Long> getBibliothequeIds();
	
	@Query(value="SELECT * FROM bibliotheque\n" + 
			"WHERE bibliotheque.id NOT IN\n" + 
			"(\n" + 
			"	SELECT idBibliotheque FROM cotisation\n" + 
			"	WHERE idUtilisateur = ?1\n" + 
			")", nativeQuery=true)
	List<Bibliotheque> getBibliothequesCotisation(long id);

	@Query(value="SELECT CAST(COUNT(1) AS BIT) FROM bibliotheque\n" + 
			"WHERE id = ?1 AND isDeleted = 1;", nativeQuery=true)
	boolean isDeleted(long id);
	
	@Modifying
	@Transactional
	@Query(value="UPDATE bibliotheque SET isDeleted = 1\n" +
			"WHERE id = ?1", nativeQuery=true)
	void delete(long id);
	
	
}
