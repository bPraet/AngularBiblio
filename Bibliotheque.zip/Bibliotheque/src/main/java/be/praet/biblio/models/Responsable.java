package be.praet.biblio.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="responsable")
public class Responsable {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id", nullable=false)
	private long id;
	@ManyToOne
	@JoinColumn(name="idadministrateur")
	Administrateur administrateur;
	@ManyToOne
	@JoinColumn(name="idbibliotheque")
	Bibliotheque bibliotheque;
	public Responsable() {
		super();
	}
	public Responsable(Administrateur administrateur, Bibliotheque bibliotheque) {
		super();
		this.administrateur = administrateur;
		this.bibliotheque = bibliotheque;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public Administrateur getAdministrateur() {
		return administrateur;
	}
	public void setAdministrateur(Administrateur administrateur) {
		this.administrateur = administrateur;
	}
	public Bibliotheque getBibliotheque() {
		return bibliotheque;
	}
	public void setBibliotheque(Bibliotheque bibliotheque) {
		this.bibliotheque = bibliotheque;
	}
	
	
}
