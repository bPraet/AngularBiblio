package be.praet.biblio.repos;

import org.springframework.data.repository.CrudRepository;

import be.praet.biblio.models.AdministrationAdmin;

public interface AdministrateurAdminRep extends CrudRepository<AdministrationAdmin, Long>{

}
