package be.praet.biblio.services;

import java.util.Date;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import be.praet.biblio.models.Administrateur;
import be.praet.biblio.models.Message;
import be.praet.biblio.models.Utilisateur;
import be.praet.biblio.repos.AdministrateurRep;
import be.praet.biblio.repos.MessageRep;
import be.praet.biblio.repos.UtilisateurRep;

@Service
public class MessageService {
	
	@Autowired
	MessageRep messageRep;
	@Autowired
	AdministrateurRep administrateurRep;
	@Autowired
	UtilisateurRep utilisateurRep;

	public Message getDetails(long id) {
		
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		Optional<Administrateur> administrateur = administrateurRep.findByLogin(authentication.getName());
		Optional<Utilisateur> utilisateur = utilisateurRep.findByLogin(authentication.getName());
		
		if(utilisateur.isPresent())
			return messageRep.getMessageUser(utilisateur.get().getId(), id);
		else
			return messageRep.getMessage(administrateur.get().getId(), id);
	}

	public String send(long id, String objet, String message) {
		
		if(objet.isEmpty() || message.isEmpty())
			return "champs obligatoires manquants";
		
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		Administrateur administrateur = administrateurRep.findByLogin(authentication.getName()).get();
		Optional<Utilisateur> utilisateur = utilisateurRep.findById(id);
		
		if((utilisateurRep.isAdminUtilisateur(administrateur.getId(), id) || administrateur.getRole().getNom().equals("Manager général")) && utilisateur.isPresent()) {
			
			Message envoi = new Message(new Date(), message, utilisateur.get(), administrateur, objet);
			messageRep.save(envoi);
			return "Message envoyé";
		}
		else
			return "Impossible d'envoyer le message";
	}
	
public String sendUser(long id, String objet, String message) {
		
		if(objet.isEmpty() || message.isEmpty())
			return "champs obligatoires manquants";
		
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		Utilisateur utilisateur = utilisateurRep.findByLogin(authentication.getName()).get();
		Optional<Administrateur> administrateur = administrateurRep.findById(id);
		
		if((utilisateurRep.isAdminUtilisateur(id, utilisateur.getId()) || administrateur.get().getRole().getNom().equals("Manager général")) && administrateur.isPresent()) {
			
			Message envoi = new Message(new Date(), message, utilisateur, administrateur.get(), objet);
			messageRep.save(envoi);
			return "Message envoyé";
		}
		else
			return "Impossible d'envoyer le message";
	}
}
