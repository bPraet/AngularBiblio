package be.praet.biblio.repos;

import org.springframework.data.repository.CrudRepository;

import be.praet.biblio.models.Responsable;

public interface ResponsableRep extends CrudRepository<Responsable, Long>{

}
