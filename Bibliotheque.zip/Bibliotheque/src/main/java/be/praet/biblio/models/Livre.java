package be.praet.biblio.models;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicUpdate;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

@Entity
@DynamicUpdate
@Table(name="livre")
@JsonIdentityInfo(
		generator = ObjectIdGenerators.PropertyGenerator.class,
		property = "id")
public class Livre {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id", nullable=false)
	private long id;
	@Column(name="nom", nullable=false)
	private String nom;
	@Column(name="EAN")
	private String ean;
	@Column(name="ISBN")
	private String isbn;
	@Column(name="edition", nullable=false)
	private String edition;
	@Column(name="auteur", nullable=false)
	private String auteur;
	@Column(name="prix", nullable=false)
	private float prix;
	@Column(name="synopsis", nullable=false)
	private String synopsis;
	@Column(name="numerique", nullable=false)
	private boolean numerique;
	@ManyToMany
	@JoinTable(
	name = "livretheme", 
	joinColumns = @JoinColumn(name = "idlivre"), 
	inverseJoinColumns = @JoinColumn(name = "idtheme"))
	private Set<Theme> themeSet;
	@OneToMany
	@JoinColumn(name="idlivre")
	private Set<Image> imageSet;
	
	public Livre() {
		super();
	}

	public Livre(long id, String nom, String ean, String isbn, String edition, String auteur, float prix,
			String synopsis, boolean numerique) {
		super();
		this.id = id;
		this.nom = nom;
		this.ean = ean;
		this.isbn = isbn;
		this.edition = edition;
		this.auteur = auteur;
		this.prix = prix;
		this.synopsis = synopsis;
		this.numerique = numerique;
	}
	
	public Livre(String nom, String ean, String isbn, String edition, String auteur, float prix, String synopsis,
			boolean numerique) {
		super();
		this.nom = nom;
		this.ean = ean;
		this.isbn = isbn;
		this.edition = edition;
		this.auteur = auteur;
		this.prix = prix;
		this.synopsis = synopsis;
		this.numerique = numerique;
	}

	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public String getEan() {
		return ean;
	}
	public void setEan(String ean) {
		this.ean = ean;
	}
	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	public String getEdition() {
		return edition;
	}
	public void setEdition(String edition) {
		this.edition = edition;
	}
	public String getAuteur() {
		return auteur;
	}
	public void setAuteur(String auteur) {
		this.auteur = auteur;
	}
	public float getPrix() {
		return prix;
	}
	public void setPrix(float prix) {
		this.prix = prix;
	}
	public String getSynopsis() {
		return synopsis;
	}
	public void setSynopsis(String synopsis) {
		this.synopsis = synopsis;
	}
	public boolean isNumerique() {
		return numerique;
	}
	public void setNumerique(boolean numerique) {
		this.numerique = numerique;
	}
	public Set<Theme> getThemeSet() {
		return themeSet;
	}
	public void setThemeSet(Set<Theme> themeSet) {
		this.themeSet = themeSet;
	}
	public Set<Image> getImageSet() {
		return imageSet;
	}
	public void setImageSet(Set<Image> imageSet) {
		this.imageSet = imageSet;
	}
	
}
