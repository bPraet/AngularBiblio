package be.praet.biblio.models;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="administrationlivre")
public class AdministrationLivre {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id", nullable=false)
	private long id;
	@Column(name="date", nullable=false)
	private Date date;
	@Column(name="action", nullable=false)
	private String action;
	@Column(name="raison", nullable=false)
	private String raison;
	@ManyToOne
	@JoinColumn(name="idlivre")
	private Livre livre;
	@ManyToOne
	@JoinColumn(name="idadministrateur")
	private Administrateur administrateur;

	public AdministrationLivre() {
		super();
	}
	public AdministrationLivre(Date date, String action, String raison, Livre livre,
			Administrateur administrateur) {
		this.date = date;
		this.action = action;
		this.raison = raison;
		this.livre = livre;
		this.administrateur = administrateur;
	}

	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getRaison() {
		return raison;
	}
	public void setRaison(String raison) {
		this.raison = raison;
	}
	public Livre getLivre() {
		return livre;
	}
	public void setLivre(Livre livre) {
		this.livre = livre;
	}
	public Administrateur getAdministrateur() {
		return administrateur;
	}
	public void setAdministrateur(Administrateur administrateur) {
		this.administrateur = administrateur;
	}
}
