package be.praet.biblio.controllers;

import java.text.ParseException;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import be.praet.biblio.models.Administrateur;
import be.praet.biblio.models.Bibliotheque;
import be.praet.biblio.models.Exemplaire;
import be.praet.biblio.models.Livre;
import be.praet.biblio.models.Location;
import be.praet.biblio.models.Message;
import be.praet.biblio.models.RoleNom;
import be.praet.biblio.models.Utilisateur;
import be.praet.biblio.services.AdministrateurService;
import be.praet.biblio.services.BibliothequeService;
import be.praet.biblio.services.ExemplaireService;
import be.praet.biblio.services.LivreService;
import be.praet.biblio.services.LocationService;
import be.praet.biblio.services.MessageService;
import be.praet.biblio.services.UtilisateurService;

@RestController
public class AdminController {
	
	@Autowired
	BibliothequeService bibliServ;
	@Autowired
	UtilisateurService userServ;
	@Autowired
	LivreService livreServ;
	@Autowired
	ExemplaireService exemplaireServ;
	@Autowired
	LocationService locationServ;
	@Autowired
	AdministrateurService administrateurServ;
	@Autowired
	MessageService messageServ;
	
	@PreAuthorize(RoleNom.Constants.BIBLIOTHECAIRE_VALUE)
	@GetMapping("/admin/bibliotheques")
	public List<Bibliotheque> bibliotheques(){
		return bibliServ.getBibliotheques();
	}
	
	@PreAuthorize(RoleNom.Constants.BIBLIOTHECAIRE_VALUE)
	@GetMapping("/admin/bibliotheque/{id}")
	public Bibliotheque bibliotheque(@PathVariable long id) {
		return bibliServ.getDetails(id);
	}
	
	@PreAuthorize(RoleNom.Constants.MANAGER_VALUE)
	@PostMapping("/admin/bibliotheque/{id}/update")
	public String updateBibliotheque(@PathVariable long id, @RequestParam String nom, @RequestParam String adresse, 
			@RequestParam String tel, @RequestParam String email, @RequestParam String web, @RequestParam String description,
			@RequestParam float amende, @RequestParam float cotisation, @RequestParam int nbLoc, @RequestParam int dureePret, @RequestParam String raison) {
		return bibliServ.setDetails(id, nom, adresse, tel, email, web, description, amende, cotisation, nbLoc, dureePret, raison);
	}
	
	@PreAuthorize(RoleNom.Constants.MANAGER_GENERAL_VALUE)
	@PostMapping("/admin/bibliotheque/add")
	public String addBibliotheque(@RequestParam String nom, @RequestParam String adresse, 
			@RequestParam String tel, @RequestParam String email, @RequestParam String web, @RequestParam String description,
			@RequestParam float amende, @RequestParam float cotisation, @RequestParam int nbLoc, @RequestParam int dureePret) {
		return bibliServ.addBibliotheque(nom, adresse, tel, email, web, description, amende, cotisation, nbLoc, dureePret);
	}
	
	@PreAuthorize(RoleNom.Constants.MANAGER_GENERAL_VALUE)
	@PostMapping("/admin/bibliotheque/{id}/remove")
	public String removeBibliotheque(@PathVariable long id) {
		return bibliServ.removeBiliotheque(id);
	}
	
	@PreAuthorize(RoleNom.Constants.BIBLIOTHECAIRE_VALUE)
	@GetMapping("/admin/utilisateurs")
	public List<Utilisateur> utilisateurs(){
		return bibliServ.getUtilisateurs();
	}
	
	@PreAuthorize(RoleNom.Constants.BIBLIOTHECAIRE_VALUE)
	@GetMapping("/admin/utilisateur/{id}")
	public Utilisateur utilisateur(@PathVariable long id) {
		return userServ.getDetails(id);
	}
	
	@PreAuthorize(RoleNom.Constants.BIBLIOTHECAIRE_VALUE)
	@PostMapping("/admin/utilisateur/{id}/update")
	public String updateUtilisateur(@PathVariable long id, @RequestParam String nom, @RequestParam String prenom, 
			@RequestParam String email, @RequestParam String login, @RequestParam String mdp, @RequestParam String dNaissance,
			@RequestParam String adresse, @RequestParam String telephone, @RequestParam String raison) {
		return userServ.setDetails(id, nom, prenom, email, login, mdp, dNaissance, adresse, telephone, raison);
	}
	
	@PreAuthorize(RoleNom.Constants.BIBLIOTHECAIRE_VALUE)
	@PostMapping("/admin/utilisateur/{id}/remove")
	public String removeUtilisateur(@PathVariable long id) {
		return bibliServ.rmUtilisateur(id);
	}
	
	@PreAuthorize(RoleNom.Constants.BIBLIOTHECAIRE_VALUE)
	@GetMapping("/admin/administrateurs")
	public List<Administrateur> administrateurs(){
		return bibliServ.getAdministrateurs();
	}
	
	@PreAuthorize(RoleNom.Constants.BIBLIOTHECAIRE_VALUE)
	@GetMapping("/admin/administrateur/{id}")
	public Administrateur administrateur(@PathVariable long id) {
		return administrateurServ.getDetails(id);
	}
	
	@PreAuthorize(RoleNom.Constants.MANAGER_VALUE)
	@PostMapping("/admin/administrateur/{id}/update")
	public String updateAdministrateur(@PathVariable long id, @RequestParam String nom, @RequestParam String prenom, 
			@RequestParam String email, @RequestParam String login, @RequestParam String mdp, @RequestParam String dNaissance,
			@RequestParam String adresse, @RequestParam String telephone, @RequestParam long idRole, @RequestParam String raison) {
		return administrateurServ.setDetails(id, nom, prenom, email, login, mdp, dNaissance, adresse, telephone, idRole, raison);
	}
	
	@PreAuthorize(RoleNom.Constants.MANAGER_VALUE)
	@PostMapping("/admin/administrateur/add")
	public String addAdministrateur(@RequestParam String nom, @RequestParam String prenom, 
			@RequestParam String email, @RequestParam String login, @RequestParam String mdp, @RequestParam String dNaissance,
			@RequestParam String adresse, @RequestParam String telephone, @RequestParam Long idRole, @RequestParam Long idBibliotheque) {
		return bibliServ.addAdministrateur(nom, prenom, email, login, mdp, dNaissance, adresse, telephone, idRole, idBibliotheque);
	}
	
	@PreAuthorize(RoleNom.Constants.MANAGER_VALUE)
	@PostMapping("/admin/administrateur/{id}/remove")
	public String removeAdministrateur(@PathVariable long id) {
		return bibliServ.rmAdministrateur(id);
	}
	
	@PreAuthorize(RoleNom.Constants.BIBLIOTHECAIRE_VALUE)
	@GetMapping("/admin/livres")
	public List<Livre> livres(){
		return bibliServ.getLivres();
	}
	
	@PreAuthorize(RoleNom.Constants.BIBLIOTHECAIRE_VALUE)
	@GetMapping("/admin/livre/{id}")
	public Livre livre(@PathVariable long id) {
		return livreServ.getDetails(id);
	}
	
	@PreAuthorize(RoleNom.Constants.BIBLIOTHECAIRE_VALUE)
	@PostMapping("/admin/livre/{id}/update")
	public String updateLivre(@PathVariable long id, @RequestParam String nom, @RequestParam String EAN, @RequestParam String ISBN, @RequestParam String edition,
			@RequestParam String auteur, @RequestParam float prix, @RequestParam String synopsis, @RequestParam boolean numerique, @RequestParam String raison) {
		return livreServ.setDetails(id, nom, EAN, ISBN, edition, auteur, prix, synopsis, numerique, raison);
	}
	
	@PreAuthorize(RoleNom.Constants.MANAGER_VALUE)
	@PostMapping("/admin/livre/add")
	public String addLivre(@RequestParam String nom, @RequestParam String EAN, @RequestParam String ISBN, @RequestParam String edition,
			@RequestParam String auteur, @RequestParam float prix, @RequestParam String synopsis, @RequestParam boolean numerique) {
		return bibliServ.addLivre(nom, EAN, ISBN, edition, auteur, prix, synopsis, numerique);
	}
	
	@PreAuthorize(RoleNom.Constants.BIBLIOTHECAIRE_VALUE)
	@PostMapping("admin/livre/{id}/setImage")
	public String setImage(@PathVariable long id, @RequestParam String lien, @RequestParam String description, @RequestParam long idLivre) {
		return livreServ.setImage(lien, description, idLivre);
	}
	
	@PreAuthorize(RoleNom.Constants.BIBLIOTHECAIRE_VALUE)
	@GetMapping("/admin/exemplaires")
	public List<Exemplaire> exemplaires(){
		return bibliServ.getExemplaires();
	}
	
	@PreAuthorize(RoleNom.Constants.BIBLIOTHECAIRE_VALUE)
	@GetMapping("/admin/exemplaire/{id}")
	public Exemplaire exemplaire(@PathVariable long id) {
		return exemplaireServ.getDetails(id);
	}
	
	@PreAuthorize(RoleNom.Constants.BIBLIOTHECAIRE_VALUE)
	@PostMapping("/admin/exemplaire/{id}/update")
	public String updateExemplaire(@PathVariable long id, @RequestParam long idEtat, @RequestParam boolean disponible, @RequestParam String raison) {
		return exemplaireServ.setDetails(id, idEtat, disponible, raison);
	}
	
	@PreAuthorize(RoleNom.Constants.BIBLIOTHECAIRE_VALUE)
	@PostMapping("/admin/exemplaire/add")
	public String addExemplaire(@RequestParam long idLivre, @RequestParam long idBibliotheque, @RequestParam long idEtat) {
		return bibliServ.addExemplaire(idLivre, idBibliotheque, idEtat);
	}
	
	@PreAuthorize(RoleNom.Constants.BIBLIOTHECAIRE_VALUE)
	@PostMapping("/admin/exemplaire/{id}/remove")
	public String rmExemplaire(@PathVariable long id) {
		return bibliServ.rmExemplaire(id);
	}
	
	@PreAuthorize(RoleNom.Constants.BIBLIOTHECAIRE_VALUE)
	@GetMapping("/admin/locations")
	public List<Location> locations(){
		return bibliServ.getLocations();
	}
	
	@PreAuthorize(RoleNom.Constants.BIBLIOTHECAIRE_VALUE)
	@GetMapping("/admin/location/{id}")
	public Location location(@PathVariable long id){
		return locationServ.getDetails(id);
	}
	
	@PreAuthorize(RoleNom.Constants.BIBLIOTHECAIRE_VALUE)
	@PostMapping("/admin/location/{id}/update")
	public String location(@PathVariable long id, @RequestParam String dateRetour) throws ParseException {
		return locationServ.setRetour(id, dateRetour);
	}
	
	@PreAuthorize(RoleNom.Constants.BIBLIOTHECAIRE_VALUE)
	@GetMapping("/admin/support")
	public List<Message> supports(){
		return userServ.getMessages();
	}
	
	@PreAuthorize(RoleNom.Constants.BIBLIOTHECAIRE_VALUE)
	@GetMapping("/admin/support/{id}")
	public Message support(@PathVariable long id){
		return messageServ.getDetails(id);
	}
	
	@PreAuthorize(RoleNom.Constants.BIBLIOTHECAIRE_VALUE)
	@PostMapping("/admin/support/{id}/send")
	public String supportSend(@PathVariable long id, @RequestParam String objet, @RequestParam String message){
		return messageServ.send(id, objet, message);
	}
}