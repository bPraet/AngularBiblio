package be.praet.biblio.repos;

import org.springframework.data.repository.CrudRepository;

import be.praet.biblio.models.Role;

public interface RoleRep extends CrudRepository<Role, Long>{

}
