package be.praet.biblio.repos;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import be.praet.biblio.models.Exemplaire;

public interface ExemplaireRep extends CrudRepository<Exemplaire, Long>{

	@Query(value="SELECT exemplaire.* FROM exemplaire\n" + 
			"INNER JOIN cotisation ON exemplaire.idBibliotheque = cotisation.idBibliotheque\n" + 
			"INNER JOIN utilisateur ON cotisation.idUtilisateur = utilisateur.id\n" + 
			"WHERE exemplaire.idLivre = ?1 AND exemplaire.disponible != 0\n" + 
			"AND utilisateur.id = ?2\n" + 
			"AND DATEADD(year, 1, cotisation.date) >= GETDATE()\n" +
			"AND exemplaire.isDeleted = 0", nativeQuery=true)
	List<Exemplaire> getAllAvailableExemplaireWhereUserSubscribedByBookId(long idLivre, long idUser);
	
	@Query(value="SELECT TOP 1 exemplaire.* FROM exemplaire\n" + 
			"INNER JOIN cotisation ON exemplaire.idBibliotheque = cotisation.idBibliotheque\n" + 
			"INNER JOIN utilisateur ON cotisation.idUtilisateur = utilisateur.id\n" + 
			"INNER JOIN location ON exemplaire.id = location.idExemplaire\n" + 
			"WHERE exemplaire.idLivre = ?1 AND exemplaire.disponible != 1\n" + 
			"AND location.dateFin >= GETDATE() AND location.dateRetour IS NULL\n" + 
			"AND utilisateur.id = ?2\n" + 
			"AND DATEADD(year, 1, cotisation.date) >= GETDATE()\n" +
			"AND exemplaire.isDeleted = 0\n" +
			"ORDER BY location.dateFin DESC", nativeQuery=true)
	List<Exemplaire> getAllNotAvailableExemplaireWhereUserSubscribedByBookId(long idLivre, long idUser);//exemplaire dans bibli cotisée disponible le + vite
	
	@Query(value="SELECT exemplaire.* FROM exemplaire\n" + 
			"INNER JOIN cotisation ON exemplaire.idBibliotheque = cotisation.idBibliotheque\n" + 
			"INNER JOIN utilisateur ON cotisation.idUtilisateur = utilisateur.id\n" + 
			"WHERE exemplaire.idLivre = ?1\n" + 
			"AND utilisateur.id = ?2\n" + 
			"AND DATEADD(year, 1, cotisation.date) < GETDATE()\n" +
			"AND exemplaire.isDeleted = 0", nativeQuery=true)
	List<Exemplaire> getAllExemplaireWhereUserNotSubscribedByBookId(long idLivre, long idUser);
	
	@Query(value="SELECT * FROM exemplaire WHERE idLivre = ?1 AND exemplaire.isDeleted = 0", nativeQuery=true)
	List<Exemplaire> getAllExemplaireByBookId(long idLivre);
	
	@Query(value="SELECT TOP 1 dateFin FROM location\n" + 
			"			WHERE location.idExemplaire = ?1\n" + 
			"			ORDER BY dateFin DESC", nativeQuery=true)
	Date getDateRetourByExemplaireId(long idExemplaire);
	
	@Modifying
	@Transactional
	@Query(value="UPDATE exemplaire SET disponible = 0 WHERE id = ?1", nativeQuery=true)
	void setUnvailable(long id);
	
	@Query(value="SELECT * FROM exemplaire WHERE isDeleted != 1", nativeQuery=true)
	List<Exemplaire> getExemplaires();

	@Query(value="SELECT exemplaire.* FROM exemplaire\n" + 
			"INNER JOIN bibliotheque ON exemplaire.idBibliotheque = bibliotheque.id\n" + 
			"INNER JOIN responsable ON bibliotheque.id = responsable.idBibliotheque\n" + 
			"INNER JOIN administrateur ON responsable.idAdministrateur = administrateur.id\n" + 
			"WHERE administrateur.id = ?1 AND exemplaire.isDeleted = 0", nativeQuery=true)
	List<Exemplaire> getExemplaires(long id);
	
	@Query(value="SELECT idExemplaire FROM location WHERE id = ?1", nativeQuery=true)
	public long getExemplaireIdFromLocation(long id);
	
	@Query(value="SELECT CAST(COUNT(1) AS BIT) FROM exemplaire\n" + 
			"WHERE id = ?1 AND isDeleted = 1;", nativeQuery=true)
	boolean isDeleted(long id);

	@Query(value="SELECT CAST(COUNT(1) AS BIT) AS exist\n" +
			"FROM exemplaire\n" + 
			"INNER JOIN bibliotheque ON exemplaire.idBibliotheque = bibliotheque.id\n" + 
			"INNER JOIN responsable ON bibliotheque.id = responsable.idBibliotheque\n" + 
			"WHERE responsable.idAdministrateur = ?1 AND exemplaire.id = ?2", nativeQuery=true)
	boolean isAdminExemplaire(long idAdmin, long idExemplaire);

	@Modifying
	@Transactional
	@Query(value="UPDATE exemplaire SET isDeleted = 1\n" +
			"WHERE id = ?1", nativeQuery=true)
	void delete(long id);
}
