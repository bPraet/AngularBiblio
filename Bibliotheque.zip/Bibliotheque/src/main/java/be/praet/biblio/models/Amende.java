package be.praet.biblio.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="amende")
public class Amende {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id", nullable=false)
	private long id;
	@Column(name="montant", nullable=false)
	private float montant;
	@Column(name="paye", nullable=false)
	private boolean paye;
	@Column(name="idutilisateur", nullable=false)
	private long idUtilisateur;
	@Column(name="idlocation", nullable=false)
	private long idLocation;
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public float getMontant() {
		return montant;
	}
	public void setMontant(float montant) {
		this.montant = montant;
	}
	public boolean isPaye() {
		return paye;
	}
	public void setPaye(boolean paye) {
		this.paye = paye;
	}
	public long getIdUtilisateur() {
		return idUtilisateur;
	}
	public void setIdUtilisateur(long idUtilisateur) {
		this.idUtilisateur = idUtilisateur;
	}
	public long getIdLocation() {
		return idLocation;
	}
	public void setIdLocation(long idLocation) {
		this.idLocation = idLocation;
	}
	
	
			
}
