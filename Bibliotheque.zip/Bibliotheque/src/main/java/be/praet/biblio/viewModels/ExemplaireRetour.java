package be.praet.biblio.viewModels;

import java.util.Date;

import be.praet.biblio.models.Exemplaire;

public class ExemplaireRetour {
	
	private Exemplaire exemplaire;
	private Date dateRetour;
	
	public ExemplaireRetour(Exemplaire exemplaire, Date dateRetour) {
		this.exemplaire = exemplaire;
		this.dateRetour = dateRetour;
	}
	
	public Exemplaire getExemplaire() {
		return exemplaire;
	}
	public void setExemplaire(Exemplaire exemplaire) {
		this.exemplaire = exemplaire;
	}
	public Date getDateRetour() {
		return dateRetour;
	}
	public void setDateRetour(Date dateRetour) {
		this.dateRetour = dateRetour;
	}
	
	
}
