package be.praet.biblio.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="exemplaire")
public class Exemplaire {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id", nullable=false)
	private long id;
	@ManyToOne
	@JoinColumn(name="idlivre")
	private Livre livre;
	@ManyToOne
	@JoinColumn(name="idbibliotheque")
	private Bibliotheque bibliotheque;
	@ManyToOne
	@JoinColumn(name="idetat")
	private Etat etat;
	private Boolean disponible;

	public Exemplaire() {
		super();
	}
	public Exemplaire(Livre livre, Bibliotheque bibliotheque, Etat etat) {
		this.livre = livre;
		this.bibliotheque = bibliotheque;
		this.etat = etat;
		disponible = true;
	}
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public Livre getLivre() {
		return livre;
	}
	public void setLivre(Livre livre) {
		this.livre = livre;
	}
	public Bibliotheque getBibliotheque() {
		return bibliotheque;
	}
	public void setBibliotheque(Bibliotheque bibliotheque) {
		this.bibliotheque = bibliotheque;
	}
	public Etat getEtat() {
		return etat;
	}
	public void setEtat(Etat etat) {
		this.etat = etat;
	}
	public Boolean getDisponible() {
		return disponible;
	}
	public void setDisponible(Boolean disponible) {
		this.disponible = disponible;
	}
	
	
}
