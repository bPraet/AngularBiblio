package be.praet.biblio.services;

import java.util.Date;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import be.praet.biblio.models.Administrateur;
import be.praet.biblio.models.AdministrationLivre;
import be.praet.biblio.models.Avis;
import be.praet.biblio.models.Image;
import be.praet.biblio.models.Livre;
import be.praet.biblio.repos.AdministrateurLivreRep;
import be.praet.biblio.repos.AdministrateurRep;
import be.praet.biblio.repos.AvisRep;
import be.praet.biblio.repos.ImageRep;
import be.praet.biblio.repos.LivreRep;
import be.praet.biblio.repos.UtilisateurRep;

@Service
public class LivreService {

	@Autowired
	public LivreRep livreRep;
	@Autowired
	public AdministrateurRep administrateurRep;
	@Autowired
	public AdministrateurLivreRep administrateurLivreRep;
	@Autowired
	public UtilisateurRep utilisateurRep;
	@Autowired
	public AvisRep avisRep;
	@Autowired
	public ImageRep imageRep;
	
	public Livre getDetails(long id) {
		return livreRep.findById(id).get();
	}
	
	public String setDetails(long id, String nom, String EAN, String ISBN, String edition, String auteur, float prix, 
			String synopsis, boolean numerique, String raison) {
		if(nom.isEmpty() || edition.isEmpty() || auteur.isEmpty() || synopsis.isEmpty() || raison.isEmpty())
			return "champs obligatoires manquants";
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		Administrateur administrateur = administrateurRep.findByLogin(authentication.getName()).get();
		Livre livre = new Livre(id, nom, EAN, ISBN, edition, auteur, prix, synopsis, numerique);
		AdministrationLivre enregistrement= new AdministrationLivre(new Date(), "UPDATE", raison, livre, administrateur);
		//livreRep.save(livre); Correction car passage de livreId dans image à null
		livreRep.updateBook(nom, EAN, ISBN, edition, auteur, prix, synopsis, numerique, id);
		administrateurLivreRep.save(enregistrement);

		return "update Done";
	}
	
	public String setAvis(String note, String commentaire, long idLivre) {
		if(commentaire.isEmpty())
			return "champs obligatoires manquants";
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		Optional<Administrateur> administrateur = administrateurRep.findByLogin(authentication.getName());
		if(administrateur.isPresent())
			return "Les administrateurs ne peuvent pas émettre d'avis !";	
		long idUtilisateur =  utilisateurRep.findByLogin(authentication.getName()).get().getId();
		if(!avisRep.isAuthorized(idUtilisateur, idLivre))
			return "Vous ne pouvez pas donner d'avis pour ce livre";
		if(avisRep.exist(idUtilisateur, idLivre))
			return "Avis pour ce livre déjà existant";
		
		long noteL;
		try {
			noteL = Long.parseLong(note);
		}catch(Exception ex) {
			return "Note incorrecte";
		}
			
		Avis avis = new Avis(noteL, commentaire, idUtilisateur, idLivre);
		avisRep.save(avis);
		return "Avis envoyé";
	}
	
	public String setImage(String lien, String description, long idLivre) {
		if(lien.isEmpty())
			return "champs obligatoires manquants";
		Image img = new Image(lien, description, idLivre);
		imageRep.save(img);
		return "Image set";
	}
}
