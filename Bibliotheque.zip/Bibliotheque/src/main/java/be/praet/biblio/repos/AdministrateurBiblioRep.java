package be.praet.biblio.repos;

import org.springframework.data.repository.CrudRepository;

import be.praet.biblio.models.AdministrationBiblio;

public interface AdministrateurBiblioRep extends CrudRepository<AdministrationBiblio, Long>{

}
