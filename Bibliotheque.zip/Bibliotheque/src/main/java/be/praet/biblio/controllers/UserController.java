package be.praet.biblio.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import be.praet.biblio.models.Amende;
import be.praet.biblio.models.Bibliotheque;
import be.praet.biblio.models.Cotisation;
import be.praet.biblio.models.Location;
import be.praet.biblio.models.Message;
import be.praet.biblio.models.Utilisateur;
import be.praet.biblio.services.AdministrateurService;
import be.praet.biblio.services.BibliothequeService;
import be.praet.biblio.services.MessageService;
import be.praet.biblio.services.UtilisateurService;

@RestController
public class UserController {
	
	@Autowired
	private BibliothequeService bibliServ;
	@Autowired
	private UtilisateurService userServ;
	@Autowired
	private AdministrateurService adminServ;
	@Autowired
	private MessageService messageServ;
	
	@GetMapping("/profil")
	public Object profile() {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		if(!authentication.getAuthorities().toString().equals("[utilisateur]"))
			return bibliServ.getAdministrateur(authentication.getName());
		else
			return bibliServ.getUtilisateur(authentication.getName());
	}
	
	@PostMapping("/setProfil")
	public String updateUtilisateur(@RequestParam String nom, @RequestParam String prenom, @RequestParam String email, @RequestParam String login, 
			@RequestParam String mdp, @RequestParam String dNaissance, @RequestParam String adresse, @RequestParam String telephone) {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		if(!authentication.getAuthorities().toString().equals("[utilisateur]"))
			return "Veuillez passer par le panneau d'administration pour modifier un administrateur.";
		Utilisateur user = bibliServ.getUtilisateur(authentication.getName());
		return userServ.updateUtilisateur(user.getId(), nom, prenom, email, login, mdp, dNaissance, adresse, telephone);
	}
	
	@GetMapping("/amendes")
	public List<Amende> amendes(){
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		if(!authentication.getAuthorities().toString().equals("[utilisateur]"))
			return null;
		Utilisateur user = bibliServ.getUtilisateur(authentication.getName());
		return userServ.getAmendes(user.getId());
	}
	
	@GetMapping("/locations")
	public List<Location> locations(){
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		if(!authentication.getAuthorities().toString().equals("[utilisateur]"))
			return null;
		Utilisateur user = bibliServ.getUtilisateur(authentication.getName());
		return userServ.getLocations(user.getId());
	}
	
	@GetMapping("/support")
	public List<Message> supports(){
		return adminServ.getMessages();
	}
	
	@GetMapping("/support/{id}")
	public Message support(@PathVariable long id){
		return messageServ.getDetails(id);
	}

	@PostMapping("/support/{id}/send")
	public String supportSend(@PathVariable long id, @RequestParam String objet, @RequestParam String message){
		return messageServ.sendUser(id, objet, message);
	}
	
	@PostMapping("/register")
	public String register(@RequestParam String nom, @RequestParam String prenom, @RequestParam String email, @RequestParam String login,
			@RequestParam String mdp, @RequestParam String dNaissance, @RequestParam String adresse, @RequestParam String telephone) {
		return bibliServ.addUtilisateur(nom, prenom, email, login, mdp, dNaissance, adresse, telephone);
	}
	
	@GetMapping("/cotisations")
	public List<Cotisation> cotisations(){
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		if(!authentication.getAuthorities().toString().equals("[utilisateur]"))
			return null;
		return bibliServ.getCotisations();
	}
	
	@GetMapping("/bibliotheques")
	public List<Bibliotheque> bibliotheques(){
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		if(!authentication.getAuthorities().toString().equals("[utilisateur]"))
			return null;
		return bibliServ.getBibliothequesCotisation();
	}
	
	@PostMapping("/cotise/{id}")
	public String cotise(@PathVariable long id) {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		if(!authentication.getAuthorities().toString().equals("[utilisateur]"))
			return "Les administrateurs ne peuvent pas cotiser";
		return bibliServ.cotise(id);
	}
	
}
