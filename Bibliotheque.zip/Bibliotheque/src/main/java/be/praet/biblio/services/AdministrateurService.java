package be.praet.biblio.services;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import be.praet.biblio.models.Administrateur;
import be.praet.biblio.models.AdministrationAdmin;
import be.praet.biblio.models.Message;
import be.praet.biblio.models.Role;
import be.praet.biblio.models.Utilisateur;
import be.praet.biblio.repos.AdministrateurAdminRep;
import be.praet.biblio.repos.AdministrateurRep;
import be.praet.biblio.repos.MessageRep;
import be.praet.biblio.repos.RoleRep;
import be.praet.biblio.repos.UtilisateurRep;

@Service
public class AdministrateurService {

	@Autowired
	AdministrateurRep administrateurRep;
	@Autowired
	AdministrateurAdminRep administrateurAdminRep;
	@Autowired
	UtilisateurRep utilisateurRep;
	@Autowired
	RoleRep roleRep;
	@Autowired
	MessageRep messageRep;
	@Autowired
	PasswordService passwordServ;
	
	public Administrateur getDetails(long id) {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		Administrateur administrateur = administrateurRep.findByLogin(authentication.getName()).get();
		if((administrateur.getRole().getNom().equals("Manager général") || administrateurRep.isAdminAdmin(administrateur.getId(), id))
				&& !administrateurRep.isDeleted(id))
			return administrateurRep.findById(id).get();
		else 
			throw new AccessDeniedException("Forbidden");
	}
	
	public String setDetails(long id, String nom, String prenom, String email, String login, String mdp, String dNaissance, String adresse, String telephone,
			long idRole, String raison) {
		if(nom.isEmpty() || prenom.isEmpty() || email.isEmpty() || login.isEmpty() || mdp.isEmpty() || dNaissance.isEmpty()
				|| adresse.isEmpty() || telephone.isEmpty() ||
				raison.isEmpty())
			return "champs obligatoires manquants";
		
		if(administrateurRep.isDeleted(id))
			throw new AccessDeniedException("Forbidden");
			
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		Administrateur administrateur = administrateurRep.findByLogin(authentication.getName()).get();
		
		if(administrateur.getRole().getNom().equals("Manager général") || administrateurRep.isAdminAdmin(administrateur.getId(), id)) {
			Role role = roleRep.findById(idRole).orElse(null);
			if(!administrateurRep.findById(id).get().getLogin().equals(login) && administrateurRep.findByLogin(login).isPresent())
				return "login déjà utilisé";
			Administrateur admin = new Administrateur(id, nom, prenom, email, login, passwordServ.hash(mdp), dNaissance, adresse, telephone, role);
			AdministrationAdmin enregistrement= new AdministrationAdmin(new Date(), "UPDATE", raison, admin, administrateur);
			try {
				administrateurRep.save(admin);
			}catch(DataAccessException daEx) {
				return "Update impossible avec les éléments entrés";
			}
			administrateurAdminRep.save(enregistrement);
			return "update Done";
		}
		throw new AccessDeniedException("Forbidden");
	}

	public List<Message> getMessages() {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		Optional<Utilisateur> utilisateur = utilisateurRep.findByLogin(authentication.getName());
		
		if(utilisateur.isPresent()) {
			return messageRep.getMessagesUser(utilisateur.get().getId());
		}
		else {
			return null;
		}
		
		
	}
}
