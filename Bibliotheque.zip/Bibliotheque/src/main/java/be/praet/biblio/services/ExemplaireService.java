package be.praet.biblio.services;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import be.praet.biblio.models.Administrateur;
import be.praet.biblio.models.AdministrationExemplaire;
import be.praet.biblio.models.Exemplaire;
import be.praet.biblio.repos.AdministrateurExemplaireRep;
import be.praet.biblio.repos.AdministrateurRep;
import be.praet.biblio.repos.EtatRep;
import be.praet.biblio.repos.ExemplaireRep;

@Service
public class ExemplaireService {

	@Autowired
	private ExemplaireRep exemplaireRep;
	@Autowired
	private AdministrateurRep administrateurRep;
	@Autowired
	private AdministrateurExemplaireRep administrateurExemplaireRep;
	@Autowired
	private EtatRep etatRep;
	
	public Exemplaire getDetails(long id) {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		Administrateur administrateur = administrateurRep.findByLogin(authentication.getName()).get();
		if((administrateur.getRole().getNom().equals("Manager général") || exemplaireRep.isAdminExemplaire(administrateur.getId(), id))
				&& !exemplaireRep.isDeleted(id))
			return exemplaireRep.findById(id).get();
		else 
			throw new AccessDeniedException("Forbidden");
	}
	
	public String setDetails(long id, long idEtat, boolean disponible, String raison) {
		if(raison.isEmpty())
			return "champs obligatoires manquants";
		
		if(exemplaireRep.isDeleted(id))
			throw new AccessDeniedException("Forbidden");
			
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		Administrateur administrateur = administrateurRep.findByLogin(authentication.getName()).get();
		
		if(administrateur.getRole().getNom().equals("Manager général") || exemplaireRep.isAdminExemplaire(administrateur.getId(), id)) {
			
			try {
				Exemplaire exemplaire = exemplaireRep.findById(id).orElse(null);
				exemplaire.setEtat(etatRep.findById(idEtat).orElse(null));
				exemplaire.setDisponible(disponible);
				AdministrationExemplaire enregistrement= new AdministrationExemplaire(new Date(), "UPDATE", raison, exemplaire, administrateur);
				exemplaireRep.save(exemplaire);
				administrateurExemplaireRep.save(enregistrement);
			}catch(DataAccessException daEx) {
				return "Update impossible avec les éléments entrés";
			}
			
			return "update Done";
		}
		throw new AccessDeniedException("Forbidden");
	}
}
