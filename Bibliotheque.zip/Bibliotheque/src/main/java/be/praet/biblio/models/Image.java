package be.praet.biblio.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="image")
public class Image {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id", nullable=false)
	private long id;
	@Column(name="lien", nullable=false)
	private String lien;
	@Column(name="description")
	private String description;
	@Column(name="idlivre", nullable=false)
	private long idLivre;
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getLien() {
		return lien;
	}
	public void setLien(String lien) {
		this.lien = lien;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	public long getIdLivre() {
		return idLivre;
	}
	public void setIdLivre(long idLivre) {
		this.idLivre = idLivre;
	}
	
	public Image() {
		super();
	}
	
	public Image(String lien, String description, long idLivre) {
		super();
		this.lien = lien;
		this.description = description;
		this.idLivre = idLivre;
	}
	
	
	
	
}
