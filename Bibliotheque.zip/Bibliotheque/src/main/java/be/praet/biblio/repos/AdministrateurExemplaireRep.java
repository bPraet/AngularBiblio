package be.praet.biblio.repos;

import org.springframework.data.repository.CrudRepository;

import be.praet.biblio.models.AdministrationExemplaire;

public interface AdministrateurExemplaireRep extends CrudRepository<AdministrationExemplaire, Long>{

}
