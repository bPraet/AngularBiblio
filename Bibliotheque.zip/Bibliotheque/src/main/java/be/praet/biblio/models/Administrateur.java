package be.praet.biblio.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="administrateur")
public class Administrateur {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id", nullable=false)
	private long id;
	@Column(name="nom", nullable=false)
	private String nom;
	@Column(name="prenom", nullable=false)
	private String prenom;
	@Column(name="email", nullable=false)
	private String email;
	@Column(name="login", nullable=false)
	private String login;
	@JsonIgnore
	@Column(name="motdepasse", nullable=false)
	private String motDePasse;
	@Column(name="datenaissance", nullable=false)
	private String dateNaissance;
	@Column(name="adresse", nullable=false)
	private String adresse;
	@Column(name="telephone")
	private String telephone;
	@ManyToOne
	@JoinColumn(name="idrole")
	private Role role;
	
	public Administrateur() {
		super();
	}

	public Administrateur(long id, String nom, String prenom, String email, String login, String motDePasse,
			String dateNaissance, String adresse, String telephone, Role role) {
		super();
		this.id = id;
		this.nom = nom;
		this.prenom = prenom;
		this.email = email;
		this.login = login;
		this.motDePasse = motDePasse;
		this.dateNaissance = dateNaissance;
		this.adresse = adresse;
		this.telephone = telephone;
		this.role = role;
	}
	
	public Administrateur(String nom, String prenom, String email, String login, String motDePasse,
			String dateNaissance, String adresse, String telephone, Role role) {
		super();
		this.nom = nom;
		this.prenom = prenom;
		this.email = email;
		this.login = login;
		this.motDePasse = motDePasse;
		this.dateNaissance = dateNaissance;
		this.adresse = adresse;
		this.telephone = telephone;
		this.role = role;
	}

	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public Role getRole() {
		return role;
	}
	public void setRole(Role role) {
		this.role = role;
	}
	public String getPrenom() {
		return prenom;
	}
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getLogin() {
		return login;
	}
	public void setLogin(String login) {
		this.login = login;
	}
	public String getMotDePasse() {
		return motDePasse;
	}
	public void setMotDePasse(String motDePasse) {
		this.motDePasse = motDePasse;
	}
	public String getDateNaissance() {
		return dateNaissance;
	}
	public void setDateNaissance(String dateNaissance) {
		this.dateNaissance = dateNaissance;
	}
	public String getAdresse() {
		return adresse;
	}
	public void setAdresse(String adresse) {
		this.adresse = adresse;
	}
	public String getTelephone() {
		return telephone;
	}
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}
}
