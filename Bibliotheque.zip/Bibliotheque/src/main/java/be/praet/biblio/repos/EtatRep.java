package be.praet.biblio.repos;

import org.springframework.data.repository.CrudRepository;

import be.praet.biblio.models.Etat;

public interface EtatRep extends CrudRepository<Etat, Long>{

}
