package be.praet.biblio.services;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import be.praet.biblio.models.Administrateur;
import be.praet.biblio.models.Exemplaire;
import be.praet.biblio.models.Location;
import be.praet.biblio.repos.AdministrateurRep;
import be.praet.biblio.repos.ExemplaireRep;
import be.praet.biblio.repos.LocationRep;

@Service
public class LocationService {
	
	@Autowired
	AdministrateurRep administrateurRep;
	@Autowired
	LocationRep locationRep;
	@Autowired
	ExemplaireRep exemplaireRep;

	public Location getDetails(long id) {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		Administrateur administrateur = administrateurRep.findByLogin(authentication.getName()).get();
		if(administrateur.getRole().getNom().equals("Manager général") || locationRep.isAdminLocation(administrateur.getId(), id))
			return locationRep.findById(id).get();
		else 
			throw new AccessDeniedException("Forbidden");
	}
	
	public String setRetour(long id, String dateRetour) throws ParseException {
		if(dateRetour.isEmpty())
			return "champs obligatoires manquants";
		
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		Administrateur administrateur = administrateurRep.findByLogin(authentication.getName()).get();
		
		if(administrateur.getRole().getNom().equals("Manager général") || locationRep.isAdminLocation(administrateur.getId(), id)) {
			Location location = locationRep.findById(id).get();
			Exemplaire exemplaire = exemplaireRep.findById(exemplaireRep.getExemplaireIdFromLocation(id)).get();
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			Date dateRetourD;
			//test date
			try {
				format.setLenient(false);
				dateRetourD = format.parse(dateRetour);
			}catch(Exception ex) {
				return "Date de naissance incorrecte";
			}
			
			location.setDateRetour(dateRetourD);
			exemplaire.setDisponible(true);
			locationRep.save(location);
			exemplaireRep.save(exemplaire);
			return "update Done";
		}
		throw new AccessDeniedException("Forbidden");
	}
}
