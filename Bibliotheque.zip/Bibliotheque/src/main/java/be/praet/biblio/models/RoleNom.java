package be.praet.biblio.models;

public enum RoleNom {
	BIBLIOTHECAIRE(Constants.BIBLIOTHECAIRE_VALUE),
	MANAGER(Constants.MANAGER_VALUE),
	MANAGER_GENERAL(Constants.MANAGER_GENERAL_VALUE);
	
	RoleNom(String droit){
	}
	
	//Annotations Spring nécessitent constantes
	public static class Constants{
		public static final String BIBLIOTHECAIRE_VALUE = "hasAuthority('Bibliothécaire') or hasAuthority('Manager') or hasAuthority('Manager général')";
		public static final String MANAGER_VALUE = "hasAuthority('Manager') or hasAuthority('Manager général')";
		public static final String MANAGER_GENERAL_VALUE = "hasAuthority('Manager général')";
	}
}
