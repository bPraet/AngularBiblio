package be.praet.biblio.repos;

import org.springframework.data.repository.CrudRepository;

import be.praet.biblio.models.AdministrationLivre;

public interface AdministrateurLivreRep extends CrudRepository<AdministrationLivre, Long>{

}
