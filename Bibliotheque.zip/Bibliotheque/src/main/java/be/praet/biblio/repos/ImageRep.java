package be.praet.biblio.repos;

import org.springframework.data.repository.CrudRepository;

import be.praet.biblio.models.Image;


public interface ImageRep extends CrudRepository<Image, Long>{

}
