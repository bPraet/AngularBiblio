package be.praet.biblio.repos;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import be.praet.biblio.models.Utilisateur;

public interface UtilisateurRep extends CrudRepository<Utilisateur, Long>{
	@Query(value="SELECT COUNT(*) FROM location \n" + 
			"INNER JOIN exemplaire ON location.idExemplaire = exemplaire.id\n" + 
			"WHERE location.idUtilisateur = ?1 AND dateRetour IS NULL AND exemplaire.idBibliotheque = ?2", nativeQuery=true)
	int getCountLocationById(long idUtilisateur, long idBibliotheque);
	
	Optional<Utilisateur> findByLogin(String login);

	@Query(value="SELECT * FROM utilisateur WHERE isDeleted != 1", nativeQuery=true)
	List<Utilisateur> getUtilisateurs();

	@Query(value="SELECT DISTINCT utilisateur.* FROM utilisateur \n" + 
			"INNER JOIN cotisation ON utilisateur.id = cotisation.idUtilisateur\n" + 
			"INNER JOIN bibliotheque ON cotisation.idBibliotheque = bibliotheque.id\n" + 
			"INNER JOIN responsable ON bibliotheque.id = responsable.idBibliotheque\n" + 
			"WHERE utilisateur.isDeleted != 1 AND DATEADD(YEAR, 1, date) > GETDATE()\n" + 
			"AND idAdministrateur = ?1", nativeQuery=true)
	List<Utilisateur> getUtilisateurs(long id);
	
	@Query(value="SELECT CAST(COUNT(1) AS BIT) FROM utilisateur \n" + 
			"WHERE id = ?1 AND isDeleted = 1", nativeQuery=true)
	boolean isDeleted(long id);

	@Query(value="SELECT CAST(COUNT(1) AS BIT) FROM utilisateur \n" + 
			"INNER JOIN cotisation ON utilisateur.id = cotisation.idUtilisateur\n" + 
			"INNER JOIN bibliotheque ON cotisation.idBibliotheque = bibliotheque.id\n" + 
			"INNER JOIN responsable ON bibliotheque.id = responsable.idBibliotheque \n" + 
			"WHERE idAdministrateur = ?1 AND utilisateur.id = ?2\n" + 
			"AND DATEADD(YEAR, 1, date) > GETDATE()", nativeQuery=true)
	boolean isAdminUtilisateur(long idAdmin, long idUtilisateur);
	
	@Modifying
	@Transactional
	@Query(value="UPDATE utilisateur SET isDeleted = 1\n" +
			"WHERE id = ?1", nativeQuery=true)
	void delete(long id);
}
