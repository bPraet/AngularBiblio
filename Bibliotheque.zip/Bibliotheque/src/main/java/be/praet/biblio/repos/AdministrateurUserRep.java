package be.praet.biblio.repos;

import org.springframework.data.repository.CrudRepository;

import be.praet.biblio.models.AdministrationUser;

public interface AdministrateurUserRep extends CrudRepository<AdministrationUser, Long>{

}
