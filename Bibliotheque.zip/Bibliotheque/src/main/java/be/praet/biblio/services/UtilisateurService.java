package be.praet.biblio.services;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import be.praet.biblio.models.Administrateur;
import be.praet.biblio.models.AdministrationUser;
import be.praet.biblio.models.Amende;
import be.praet.biblio.models.Location;
import be.praet.biblio.models.Message;
import be.praet.biblio.models.Utilisateur;
import be.praet.biblio.repos.AdministrateurRep;
import be.praet.biblio.repos.AdministrateurUserRep;
import be.praet.biblio.repos.AmendeRep;
import be.praet.biblio.repos.LocationRep;
import be.praet.biblio.repos.MessageRep;
import be.praet.biblio.repos.UtilisateurRep;

@Service
public class UtilisateurService {
	
	@Autowired
	private UtilisateurRep utilisateurRep;
	@Autowired
	private AdministrateurRep administrateurRep;
	@Autowired
	private AmendeRep amendeRep;
	@Autowired
	private LocationRep locationRep;
	@Autowired
	private AdministrateurUserRep administrateurUserRep;
	@Autowired
	private MessageRep messageRep;
	@Autowired
	private PasswordService passwordServ;
	
	public Utilisateur getDetails(long id) {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		Administrateur administrateur = administrateurRep.findByLogin(authentication.getName()).get();
		if((administrateur.getRole().getNom().equals("Manager général") || utilisateurRep.isAdminUtilisateur(administrateur.getId(), id))
				&& !utilisateurRep.isDeleted(id))
			return utilisateurRep.findById(id).get();
		else 
			throw new AccessDeniedException("Forbidden");
	}
	
	public String updateUtilisateur(long id, String nom, String prenom, String email, String login, String mdp, String dNaissance,	//USER
			String adresse, String telephone) {
		if(nom.isEmpty() || prenom.isEmpty() || email.isEmpty() || login.isEmpty() || mdp.isEmpty() || dNaissance.isEmpty()
				|| adresse.isEmpty() || telephone.isEmpty())
			return "champs obligatoires manquants";
		
		//Password control
		String regexMdp = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}$"; // 8char, 1Maj, 1special, 0space
		if(!mdp.matches(regexMdp))
			return "Mot de passe pas assez sécurisé";
		//login control
		Optional<Administrateur> admin = administrateurRep.findByLogin(login);
		if(admin.isPresent())
			return "login déjà utilisé";
		
		Optional<Utilisateur> user = utilisateurRep.findByLogin(login);
		if(user.isPresent() && !utilisateurRep.findById(id).get().getLogin().equals(login))
			return "login déjà utilisé";
		//Email control
		String regexEmail = "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$";
		if(!email.matches(regexEmail))
			return "email incorrect";
		//dNaissance control
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			sdf.setLenient(false);
			Date dNaissanceD = sdf.parse(dNaissance);
		}catch(Exception ex) {
			return "Date de naissance incorrecte";
		}
		
		Utilisateur utilisateur = new Utilisateur(id, nom, prenom, email, login, passwordServ.hash(mdp), dNaissance, adresse, telephone);
		try {
			utilisateurRep.save(utilisateur);
		}catch(DataAccessException daEx) {
			return "Update impossible avec les éléments entrés";
		}
		return "update Done";
	}
	
	public String setDetails(long id, String nom, String prenom, String email, String login, String mdp, String dNaissance,			//ADMIN
			String adresse, String telephone, String raison) {
		if(nom.isEmpty() || prenom.isEmpty() || email.isEmpty() || login.isEmpty() || mdp.isEmpty() || dNaissance.isEmpty()
				|| adresse.isEmpty() || telephone.isEmpty() ||
				raison.isEmpty())
			return "champs obligatoires manquants";
		
		if(utilisateurRep.isDeleted(id) || !utilisateurRep.findById(id).isPresent())
			throw new AccessDeniedException("Forbidden");
			
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		Administrateur administrateur = administrateurRep.findByLogin(authentication.getName()).get();
		
		if(administrateur.getRole().getNom().equals("Manager général") || utilisateurRep.isAdminUtilisateur(administrateur.getId(), id)) {
			
			//Password control
			String regexMdp = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}$"; // 8char, 1Maj, 1special, 0space
			if(!mdp.matches(regexMdp))
				return "Mot de passe pas assez sécurisé";
			//login control
			Optional<Administrateur> admin = administrateurRep.findByLogin(login);
			if(admin.isPresent())
				return "login déjà utilisé";
			
			Optional<Utilisateur> user = utilisateurRep.findByLogin(login);
			if(user.isPresent() && !utilisateurRep.findById(id).get().getLogin().equals(login))
				return "login déjà utilisé";
			//Email control
			String regexEmail = "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$";
			if(!email.matches(regexEmail))
				return "email incorrect";
			//dNaissance control
			try {
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				sdf.setLenient(false);
				Date dNaissanceD = sdf.parse(dNaissance);
			}catch(Exception ex) {
				return "Date de naissance incorrecte";
			}
			
			Utilisateur utilisateur = new Utilisateur(id, nom, prenom, email, login, passwordServ.hash(mdp), dNaissance, adresse, telephone);
			AdministrationUser enregistrement= new AdministrationUser(new Date(), "UPDATE", raison, utilisateur, administrateur);
			try {
				utilisateurRep.save(utilisateur);
			}catch(DataAccessException daEx) {
				return "Update impossible avec les éléments entrés";
			}
			administrateurUserRep.save(enregistrement);
			return "update Done";
		}
		throw new AccessDeniedException("Forbidden");
	}
	
	public List<Amende> getAmendes(long id){
		return amendeRep.getAmendeByUserId(id);
	}
	
	public List<Location> getLocations(long id){
		return locationRep.getLocations(id);
	}

	public List<Message> getMessages() {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		Administrateur administrateur = administrateurRep.findByLogin(authentication.getName()).get();
		
		return messageRep.getMessages(administrateur.getId());
	}
}
