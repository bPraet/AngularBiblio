package be.praet.biblio.repos;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import be.praet.biblio.models.Administrateur;

public interface AdministrateurRep extends CrudRepository<Administrateur, Long>{

	Optional<Administrateur> findByLogin(String login);

	@Query(value="SELECT * FROM administrateur WHERE isDeleted != 1", nativeQuery=true)
	List<Administrateur> getAdministrateurs();

	@Query(value="SELECT administrateur.* FROM administrateur\n" + 
			"INNER JOIN responsable ON responsable.idAdministrateur = administrateur.id\n" + 
			"WHERE responsable.idBibliotheque = (SELECT idBibliotheque FROM responsable\n" + 
			"WHERE idAdministrateur = ?1) AND isDeleted != 1", nativeQuery=true)
	List<Administrateur> getAdministrateurs(long id);

	@Query(value="SELECT CAST(COUNT(1) AS BIT) FROM administrateur \n" + 
			"WHERE id = ?1 AND isDeleted = 1", nativeQuery=true)
	boolean isDeleted(long id);

	@Query(value="SELECT CAST(COUNT(1) AS BIT) FROM administrateur\n" + 
			"INNER JOIN responsable ON responsable.idAdministrateur = administrateur.id\n" + 
			"WHERE responsable.idBibliotheque = (SELECT idBibliotheque FROM responsable\n" + 
			"WHERE idAdministrateur = ?1) AND isDeleted != 1 AND administrateur.id = ?2", nativeQuery=true)
	boolean isAdminAdmin(long idAdmin, long idAdminCible);

	@Modifying
	@Transactional
	@Query(value="UPDATE administrateur SET isDeleted = 1\n" +
			"WHERE id = ?1", nativeQuery=true)
	void delete(long id);
}
