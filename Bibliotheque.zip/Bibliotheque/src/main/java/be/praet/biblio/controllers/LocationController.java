package be.praet.biblio.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import be.praet.biblio.services.BibliothequeService;

@RestController
public class LocationController {

	@Autowired
	private BibliothequeService bibliServ;
	
	@PostMapping("/location")
	public String location(@RequestParam long idExemplaire) {
		try {
			if(bibliServ.controlLocation(idExemplaire) != null)
				return bibliServ.controlLocation(idExemplaire);
			else {
				bibliServ.location(idExemplaire);
				return "Location OK";
			}
		}catch(DataAccessException | NullPointerException ex) {
			return "Exemplaire inexistant";
		}
	}
	
	@PostMapping("/reserve")
	public String reserve(@RequestParam long idExemplaire) {
		try {
			if(bibliServ.controlReservation(idExemplaire) != null)
				return bibliServ.controlReservation(idExemplaire);
			else if(bibliServ.reserve(idExemplaire))
				return "Reservation OK";
			else
				return "Réservation impossible";
		}catch(DataAccessException | NullPointerException ex) {
			return "Exemplaire inexistant";
		}	
	}
}
