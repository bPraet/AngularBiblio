package be.praet.biblio.security.jwt;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import be.praet.biblio.models.Administrateur;
import be.praet.biblio.models.Utilisateur;
import be.praet.biblio.repos.AdministrateurRep;
import be.praet.biblio.repos.UtilisateurRep;



@Service
public class JwtInMemoryUserDetailsService implements UserDetailsService {

  @Autowired
  private UtilisateurRep utilisateurRep;
  @Autowired
  private AdministrateurRep administrateurRep;

  @Override
  public UserDetails loadUserByUsername(String login) throws UsernameNotFoundException {
    
	  Optional<Utilisateur> utilisateur = utilisateurRep.findByLogin(login);
	  Optional<Administrateur> administrateur = administrateurRep.findByLogin(login);
	    
	  Optional<JwtUserDetails> user = Optional.empty();
	  
	  if(utilisateur.isPresent()) {
		  if(!utilisateurRep.isDeleted(utilisateur.get().getId()))
			  user = Optional.of(new JwtUserDetails(utilisateur.get().getId(),utilisateur.get().getLogin(),utilisateur.get().getMotDePasse(),"utilisateur"));
		  else 
			  throw new UsernameNotFoundException(String.format("USER_DELETED '%s'.", login));
	  }
	  else if(administrateur.isPresent()) {
		  if(!administrateurRep.isDeleted(administrateur.get().getId()))
			  user = Optional.of(new JwtUserDetails(administrateur.get().getId(),administrateur.get().getLogin(),administrateur.get().getMotDePasse(),administrateur.get().getRole().getNom()));
		  else
			  throw new UsernameNotFoundException(String.format("USER_DELETED '%s'.", login));
	  }
	  else {
		  throw new UsernameNotFoundException(String.format("USER_NOT_FOUND '%s'.", login));
	  }

	  return user.get();
  }

}