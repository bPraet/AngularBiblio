package be.praet.biblio.services;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import be.praet.biblio.models.Administrateur;
import be.praet.biblio.models.AdministrationAdmin;
import be.praet.biblio.models.AdministrationBiblio;
import be.praet.biblio.models.AdministrationExemplaire;
import be.praet.biblio.models.AdministrationLivre;
import be.praet.biblio.models.AdministrationUser;
import be.praet.biblio.models.Bibliotheque;
import be.praet.biblio.models.Cotisation;
import be.praet.biblio.models.Etat;
import be.praet.biblio.models.Exemplaire;
import be.praet.biblio.models.Livre;
import be.praet.biblio.models.Location;
import be.praet.biblio.models.Responsable;
import be.praet.biblio.models.Role;
import be.praet.biblio.models.Utilisateur;
import be.praet.biblio.repos.AdministrateurAdminRep;
import be.praet.biblio.repos.AdministrateurBiblioRep;
import be.praet.biblio.repos.AdministrateurExemplaireRep;
import be.praet.biblio.repos.AdministrateurLivreRep;
import be.praet.biblio.repos.AdministrateurRep;
import be.praet.biblio.repos.AdministrateurUserRep;
import be.praet.biblio.repos.AmendeRep;
import be.praet.biblio.repos.BibliothequeRep;
import be.praet.biblio.repos.CotisationRep;
import be.praet.biblio.repos.EtatRep;
import be.praet.biblio.repos.ExemplaireRep;
import be.praet.biblio.repos.LivreRep;
import be.praet.biblio.repos.LocationRep;
import be.praet.biblio.repos.ResponsableRep;
import be.praet.biblio.repos.RoleRep;
import be.praet.biblio.repos.UtilisateurRep;
import be.praet.biblio.viewModels.ExemplaireRetour;

@Service
public class BibliothequeService {
	
	@Autowired
	private LivreRep livreRep;
	@Autowired
	private ExemplaireRep exemplaireRep;
	@Autowired
	private LocationRep locationRep;
	@Autowired
	private UtilisateurRep utilisateurRep;
	@Autowired
	private AmendeRep amendeRep;
	@Autowired
	private CotisationRep cotisationRep;
	@Autowired
	private BibliothequeRep bibliothequeRep;
	@Autowired
	private AdministrateurRep administrateurRep;
	@Autowired
	private RoleRep roleRep;
	@Autowired
	private EtatRep etatRep;
	@Autowired
	private AdministrateurBiblioRep administrateurBiblioRep;
	@Autowired
	private AdministrateurLivreRep administrateurLivreRep;
	@Autowired
	private AdministrateurExemplaireRep administrateurExemplaireRep;
	@Autowired
	private AdministrateurUserRep administrateurUserRep;
	@Autowired
	private AdministrateurAdminRep administrateurAdminRep;
	@Autowired
	private ResponsableRep responsableRep;
	@Autowired
	private PasswordService passwordServ;
	
	//LOCATION
	public Map<Boolean, List<Livre>> getLivresForUtilisateur(){
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		Optional<Utilisateur> user = utilisateurRep.findByLogin(authentication.getName());
		Map<Boolean, List<Livre>> booksMap = new HashMap<Boolean, List<Livre>>();
		
		if(!authentication.getAuthorities().toString().equals("[utilisateur]")) {
			booksMap.put(true, (List<Livre>) livreRep.findAll());
		}
		else {
			List<Livre> booksSubscribed = livreRep.findAllBookWhereUserSubscribed(user.get().getId());
			List<Livre> booksNotSubscribed = livreRep.findAllBookWhereUserDidNotSubscribed(user.get().getId());
			booksMap.put(true, booksSubscribed);
			booksMap.put(false, booksNotSubscribed);	
		}	
		return booksMap;
	}
	
	public Map<String, List<ExemplaireRetour>> getLivreForUtilisateur(long id) {
		
		Map<String, List<ExemplaireRetour>> exemplairesMap = new HashMap<String, List<ExemplaireRetour>>();
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		Optional<Utilisateur> user = utilisateurRep.findByLogin(authentication.getName());
		ExemplaireRetour exRetour;
		List<ExemplaireRetour> exemplairesRetour = new ArrayList<ExemplaireRetour>();
		if(!authentication.getAuthorities().toString().equals("[utilisateur]")) {
			List<Exemplaire> exemplaires = exemplaireRep.getAllExemplaireByBookId(id);
			for(Exemplaire exemplaire : exemplaires) {
				exRetour = new ExemplaireRetour(exemplaire, null);
				exemplairesRetour.add(exRetour);
			}
			exemplairesMap.put("admin view: location forbidden", exemplairesRetour);
			return exemplairesMap;
		}
		else {
			List<Exemplaire> availableNow = exemplaireRep.getAllAvailableExemplaireWhereUserSubscribedByBookId(id, user.get().getId());
			//Disponible
			
			
			for(Exemplaire exemplaire : availableNow) {
				exRetour = new ExemplaireRetour(exemplaire, null);
				exemplairesRetour.add(exRetour);
			}	
			if(!availableNow.isEmpty()) {
				exemplairesMap.put("availableNow", exemplairesRetour);
				return exemplairesMap;
			}
			
			//Bientôt disponible
			List<Exemplaire> availableSoon = exemplaireRep.getAllNotAvailableExemplaireWhereUserSubscribedByBookId(id, user.get().getId());
			for(Exemplaire exemplaire : availableSoon) {
				exRetour = new ExemplaireRetour(exemplaire, exemplaireRep.getDateRetourByExemplaireId(exemplaire.getId()));
				exemplairesRetour.add(exRetour);
			}	
			if(!availableSoon.isEmpty()) {
				exemplairesMap.put("availableSoon", exemplairesRetour);
				return exemplairesMap;
			}
			
			//Pas disponible
			List<Exemplaire> notAvailable = exemplaireRep.getAllExemplaireWhereUserNotSubscribedByBookId(id, user.get().getId());
			for(Exemplaire exemplaire : notAvailable) {
				exRetour = new ExemplaireRetour(exemplaire, exemplaireRep.getDateRetourByExemplaireId(exemplaire.getId()));
				exemplairesRetour.add(exRetour);
			}
			if(!notAvailable.isEmpty()) {
				exemplairesMap.put("notAvailable", exemplairesRetour);
				return exemplairesMap;
			}
			
			exemplairesMap.put("nothingAvailable", null);
			return exemplairesMap;
		}
		

	}
	
	public String controlLocation(long idExemplaire) {
		Exemplaire exemplaire = exemplaireRep.findById(idExemplaire).orElse(null);
		if(controlUser(idExemplaire) != null)
			return controlUser(idExemplaire);
		
		else if(!exemplaire.getDisponible())
			return "Livre indisponible";
		
		return null;
	}
	
	public String controlReservation(long idExemplaire) {
		Exemplaire exemplaire = exemplaireRep.findById(idExemplaire).orElse(null);
		if(controlUser(idExemplaire) != null)
			return controlUser(idExemplaire);
		
		else if(exemplaire.getDisponible())
			return "Livre déjà disponible";
		
		return null;
	}
	
	private String controlUser(long idExemplaire) {
		Exemplaire exemplaire = exemplaireRep.findById(idExemplaire).orElse(null);
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		Optional<Utilisateur> user = utilisateurRep.findByLogin(authentication.getName());
		
		if(!authentication.getAuthorities().toString().equals("[utilisateur]"))
			return "Admin view: location forbidden";
		if(!amendeRep.getUnpaidAmendeById(user.get().getId()).isEmpty())
			return "Vous avez des amendes impayées";
		if(utilisateurRep.getCountLocationById(user.get().getId(), exemplaire.getBibliotheque().getId()) >= exemplaire.getBibliotheque().getNbLocation())
			return "Nombre maximum de location atteint pour cette bibliotheque";
		else if(cotisationRep.getCotisationById(user.get().getId(), exemplaire.getBibliotheque().getId()) == null)
			return "Aucune cotisation pour active pour cette bibliotheque";
		return null;
	}
	
	public void location(long idExemplaire) {
		
		Exemplaire exemplaire = exemplaireRep.findById(idExemplaire).orElse(null);
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		Utilisateur utilisateur = utilisateurRep.findByLogin(authentication.getName()).get();
		
		Calendar calendar = Calendar.getInstance();
		Date dateDebut = new Date();
		Date dateFin = new Date();
		
		calendar.setTime(dateDebut);
		calendar.add(Calendar.DATE, 1);
		
		if(calendar.get(Calendar.DAY_OF_WEEK) == 1) // Si dimanche ajouter un jour
			calendar.add(Calendar.DATE, 1);
		
		dateDebut = calendar.getTime();
		calendar.add(Calendar.DAY_OF_WEEK, exemplaire.getBibliotheque().getDureePret());
		dateFin = calendar.getTime();

		Location location = new Location(dateDebut, dateFin, exemplaire, utilisateur);
		
		locationRep.save(location);
		exemplaireRep.setUnvailable(idExemplaire);
	}
	
	public boolean reserve(long idExemplaire) {
		
		Exemplaire exemplaire = exemplaireRep.findById(idExemplaire).get();
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		Utilisateur utilisateur = utilisateurRep.findByLogin(authentication.getName()).get();
		
		Date today = new Date();
		Date dateRetour = exemplaireRep.getDateRetourByExemplaireId(exemplaire.getId());
	
		if(dateRetour != null && dateRetour.after(today)) {
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(dateRetour);
				
			calendar.add(Calendar.DATE, 1);
			if(calendar.get(Calendar.DAY_OF_WEEK) == 1) // Si dimanche ajouter un jour
				calendar.add(Calendar.DATE, 1);
			
			Date dateDebut = calendar.getTime();
			
			calendar.add(Calendar.DATE, exemplaire.getBibliotheque().getDureePret());
			Date dateFin = calendar.getTime();
			
			Location location = new Location(dateDebut, dateFin, exemplaire, utilisateur);
			
			locationRep.save(location);
			return true; //Réservation effectuée
		}
		return false;	
	}
	
	public List<Location> getLocations(){
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		Administrateur administrateur = administrateurRep.findByLogin(authentication.getName()).get();
		if(administrateur.getRole().getNom().equals("Manager général"))
			return (List<Location>) locationRep.getLocationsAdmin();
		else
			return (List<Location>) locationRep.getLocationsAdmin(administrateur.getId());
	}
	
	//BIBLIOTHEQUES
	public List<Bibliotheque> getBibliotheques(){
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		Administrateur administrateur = administrateurRep.findByLogin(authentication.getName()).get();
		if(administrateur.getRole().getNom().equals("Manager général"))
			return (List<Bibliotheque>)bibliothequeRep.getBibliotheques();
		else
			return (List<Bibliotheque>) bibliothequeRep.getBibliotheques(administrateur.getId());
	}
	
	public Bibliotheque getDetails(long id) {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		Administrateur administrateur = administrateurRep.findByLogin(authentication.getName()).get();
		if((administrateur.getRole().getNom().equals("Manager général") || bibliothequeRep.getBibliothequeIdByAdmin(administrateur.getId()).contains(id))
				&& !bibliothequeRep.isDeleted(id))
			return bibliothequeRep.findById(id).get();
		else 
			throw new AccessDeniedException("Forbidden");
	}
	
	public String setDetails(long id, String nom, String adresse, String tel, String email,
			String web, String description, float amende, float cotisation, int nbLoc, int dureePret, String raison) {

		if(nom.isEmpty() || adresse.isEmpty() || tel.isEmpty() || email.isEmpty() || web.isEmpty() || description.isEmpty() ||
				raison.isEmpty())
			return "champs obligatoires manquants";
		
		if(bibliothequeRep.isDeleted(id))
			throw new AccessDeniedException("Forbidden");
			
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		Administrateur administrateur = administrateurRep.findByLogin(authentication.getName()).get();
		
		if(administrateur.getRole().getNom().equals("Manager général") || bibliothequeRep.getBibliothequeIdByAdmin(administrateur.getId()).contains(id)) {
			Bibliotheque bibliotheque = new Bibliotheque(id, nom, adresse, tel, email, web, description, amende, cotisation, nbLoc, dureePret);
			AdministrationBiblio enregistrement= new AdministrationBiblio(new Date(), "UPDATE", raison, bibliotheque, administrateur);
			bibliothequeRep.save(bibliotheque);
			administrateurBiblioRep.save(enregistrement);
			return "update Done";
		}
		throw new AccessDeniedException("Forbidden");
	}
	
	public String addBibliotheque(String nom, String adresse, String tel, String email,
			String web, String description, float amende, float cotisation, int nbLoc, int dureePret) {
		if(nom.isEmpty() || adresse.isEmpty() || tel.isEmpty() || email.isEmpty() || web.isEmpty() || description.isEmpty())
			return "champs obligatoires manquants";
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		Administrateur administrateur = administrateurRep.findByLogin(authentication.getName()).get();
		Bibliotheque bibliotheque = new Bibliotheque(nom, adresse, tel, email, web, description, amende, cotisation, nbLoc, dureePret);
		AdministrationBiblio enregistrement= new AdministrationBiblio(new Date(), "ADD", "Nouvelle bibliothèque",bibliotheque, administrateur);
		bibliothequeRep.save(bibliotheque);
		administrateurBiblioRep.save(enregistrement);
		return "add Done";
	}
	
	public String removeBiliotheque(long id) {
		if(bibliothequeRep.isDeleted(id))
			return "already deleted";
		Bibliotheque bibliotheque = bibliothequeRep.findById(id).get();
		bibliothequeRep.delete(id);
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		Administrateur administrateur = administrateurRep.findByLogin(authentication.getName()).get();
		AdministrationBiblio enregistrement= new AdministrationBiblio(new Date(), "DELETE", "Suppression bibliothèque",bibliotheque, administrateur);
		administrateurBiblioRep.save(enregistrement);
		return "remove Done";
	}
	
	//LIVRES
	public List<Livre> getLivres(){
		return (List<Livre>)livreRep.findAll();
	}
	
	public String addLivre(String nom, String EAN, String ISBN, String edition, String auteur, float prix, String synopsis,
			boolean numerique) {
		if(nom.isEmpty() || EAN.isEmpty() || ISBN.isEmpty() || edition.isEmpty() || auteur.isEmpty() || synopsis.isEmpty())
			return "champs obligatoires manquants";
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		Administrateur administrateur = administrateurRep.findByLogin(authentication.getName()).get();
		Livre livre = new Livre(nom, EAN, ISBN, edition, auteur, prix, synopsis, numerique);
		AdministrationLivre enregistrement= new AdministrationLivre(new Date(), "ADD", "Nouveau livre", livre, administrateur);
		livreRep.save(livre);
		administrateurLivreRep.save(enregistrement);
		return "add Done";
	}
	
	//EXEMPLAIRES
	public List<Exemplaire> getExemplaires(){
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		Administrateur administrateur = administrateurRep.findByLogin(authentication.getName()).get();
		if(administrateur.getRole().getNom().equals("Manager général"))
			return (List<Exemplaire>) exemplaireRep.getExemplaires();
		else
			return (List<Exemplaire>) exemplaireRep.getExemplaires(administrateur.getId());
	}
	
	public String addExemplaire(long idLivre, long idBibliotheque, long idEtat) {		
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		Administrateur administrateur = administrateurRep.findByLogin(authentication.getName()).get();
		if(!administrateur.getRole().getNom().equals("Manager général"))
			if(!bibliothequeRep.getBibliothequeIdByAdmin(administrateur.getId()).contains(idBibliotheque))
				throw new AccessDeniedException("Forbidden");
		Livre livre = livreRep.findById(idLivre).get();
		Bibliotheque bibliotheque = bibliothequeRep.findById(idBibliotheque).get();
		Etat etat = etatRep.findById(idEtat).get();
		Exemplaire exemplaire = new Exemplaire(livre, bibliotheque, etat);
		AdministrationExemplaire enregistrement= new AdministrationExemplaire(new Date(), "ADD", "Nouvel exemplaire", exemplaire, administrateur);
		exemplaireRep.save(exemplaire);
		administrateurExemplaireRep.save(enregistrement);
		return "add Done";
	}
	
	public String rmExemplaire(long id) {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		Administrateur administrateur = administrateurRep.findByLogin(authentication.getName()).get();
		
		if(administrateur.getRole().getNom().equals("Manager général") || exemplaireRep.isAdminExemplaire(administrateur.getId(), id)) {
			if(exemplaireRep.isDeleted(id))
				return "already deleted";
			Exemplaire exemplaire = exemplaireRep.findById(id).get();
			exemplaireRep.delete(id);
			AdministrationExemplaire enregistrement= new AdministrationExemplaire(new Date(), "DELETE", "Suppression exemplaire", exemplaire, administrateur);
			administrateurExemplaireRep.save(enregistrement);
			return "remove Done";
		}
		
		throw new AccessDeniedException("Forbidden");
	}
	
	//UTILISATEURS
		public List<Utilisateur> getUtilisateurs(){
			Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
			Administrateur administrateur = administrateurRep.findByLogin(authentication.getName()).get();
			if(administrateur.getRole().getNom().equals("Manager général"))
				return (List<Utilisateur>) utilisateurRep.getUtilisateurs();
			else
				return (List<Utilisateur>) utilisateurRep.getUtilisateurs(administrateur.getId());
		}
		
		public Utilisateur getUtilisateur(String login) {
			return utilisateurRep.findByLogin(login).get();
		}
		
		public String rmUtilisateur(long id) {
			Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
			Administrateur administrateur = administrateurRep.findByLogin(authentication.getName()).get();
			
			if(administrateur.getRole().getNom().equals("Manager général") || utilisateurRep.isAdminUtilisateur(administrateur.getId(), id)) {
				if(utilisateurRep.isDeleted(id))
					return "already deleted";
				Utilisateur utilisateur = utilisateurRep.findById(id).get();
				utilisateurRep.delete(id);
				AdministrationUser enregistrement= new AdministrationUser(new Date(), "DELETE", "Suppression utilisateur", utilisateur, administrateur);
				administrateurUserRep.save(enregistrement);
				return "remove Done";
			}
			
			throw new AccessDeniedException("Forbidden");
		}
		
		public String addUtilisateur(String nom, String prenom, String email, String login, String mdp, 
				String dNaissance, String adresse, String telephone) {
			if(nom.isEmpty() || prenom.isEmpty() || email.isEmpty() || login.isEmpty() || mdp.isEmpty() || dNaissance.isEmpty() ||
					adresse.isEmpty() || telephone.isEmpty())
				return "champs obligatoires manquants";
			
			//Password control
			String regexMdp = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}$"; // 8char, 1Maj, 1special, 0space
			if(!mdp.matches(regexMdp))
				return "Mot de passe pas assez sécurisé";
			//login control
			Optional<Administrateur> administrateur = administrateurRep.findByLogin(login);
			if(administrateur.isPresent())
				return "login déjà utilisé";
			
			Optional<Utilisateur> utilisateur = utilisateurRep.findByLogin(login);
			if(utilisateur.isPresent())
				return "login déjà utilisé";
			//Email control
			String regexEmail = "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$";
			if(!email.matches(regexEmail))
				return "email incorrect";
			//dNaissance control
			try {
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				sdf.setLenient(false);
				Date dNaissanceD = sdf.parse(dNaissance);
			}catch(Exception ex) {
				return "Date de naissance incorrecte";
			}
			
			Utilisateur user = new Utilisateur(nom, prenom, email, login, passwordServ.hash(mdp), dNaissance, adresse, telephone);
			utilisateurRep.save(user);
			return "done";
		}
		
	//ADMINISTRATEURS
		public List<Administrateur> getAdministrateurs(){
			Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
			Administrateur administrateur = administrateurRep.findByLogin(authentication.getName()).get();
			if(administrateur.getRole().getNom().equals("Manager général"))
				return (List<Administrateur>) administrateurRep.getAdministrateurs();
			else
				return (List<Administrateur>) administrateurRep.getAdministrateurs(administrateur.getId());
		}
		
		public Administrateur getAdministrateur(String login) {
			return administrateurRep.findByLogin(login).get();
		}
		
		@Transactional
		public String addAdministrateur(String nom, String prenom, String email, String login, String mdp, String dNaissance,
				String adresse, String telephone, Long idRole, Long idBibliotheque) {
			if(nom.isEmpty() || prenom.isEmpty() || email.isEmpty() || login.isEmpty() || mdp.isEmpty() || dNaissance.isEmpty() ||
					adresse.isEmpty() || telephone.isEmpty())
				return "champs obligatoires manquants";
			if(administrateurRep.findByLogin(login).isPresent())
				return "login déjà utilisé";
			Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
			Administrateur administrateur = administrateurRep.findByLogin(authentication.getName()).get();
			if(!administrateur.getRole().getNom().equals("Manager général")) {
				idRole = (long) 3;
				idBibliotheque = bibliothequeRep.getBibliothequeIdByAdmin(administrateur.getId()).get(0);
			}
			else if(idRole == null)
				return "Role requis";
			else if(idBibliotheque == null)
				return "Bibliotheque requise";
				
			Role role = roleRep.findById(idRole).orElse(null);
			Bibliotheque bibliotheque = bibliothequeRep.findById(idBibliotheque).orElse(null);
			Administrateur admin = new Administrateur(nom, prenom, email, login, passwordServ.hash(mdp), dNaissance, adresse, telephone, role);
			AdministrationAdmin enregistrement = new AdministrationAdmin(new Date(), "ADD", "Nouvel administrateur", admin, administrateur);
			Responsable responsable = new Responsable(admin, bibliotheque);
			try {
				administrateurRep.save(admin);
			}catch(DataAccessException daEx) {
				return "Rôle incorrect !";
			}
			try {
				responsableRep.save(responsable);
			}catch(DataAccessException daEx) {
				return "Bibliotheque incorrecte !";
			}
			administrateurAdminRep.save(enregistrement);
			
			return "add Done";
		}

		public String rmAdministrateur(long id) {
			Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
			Administrateur administrateur = administrateurRep.findByLogin(authentication.getName()).get();
			
			if(administrateur.getRole().getNom().equals("Manager général") || administrateurRep.isAdminAdmin(administrateur.getId(), id)) {
				if(administrateurRep.isDeleted(id))
					return "already deleted";
				Administrateur admin = administrateurRep.findById(id).get();
				administrateurRep.delete(id);
				AdministrationAdmin enregistrement= new AdministrationAdmin(new Date(), "DELETE", "Suppression administrateur", admin, administrateur);
				administrateurAdminRep.save(enregistrement);
				return "remove Done";
			}
			
			throw new AccessDeniedException("Forbidden");
		}
		
		//COTISATION
		public List<Cotisation> getCotisations(){
			Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
			Utilisateur utilisateur = utilisateurRep.findByLogin(authentication.getName()).get();
			
			List<Cotisation> cotisations = new ArrayList<Cotisation>();
			for(long idBibliotheque : bibliothequeRep.getBibliothequeIds()) {
				Cotisation cotisation = cotisationRep.getCotisationById(utilisateur.getId(), idBibliotheque);
				if(cotisation != null)
					cotisations.add(cotisation);	
			}
			
			return cotisations;
		}
		
		public List<Bibliotheque> getBibliothequesCotisation(){
			Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
			Utilisateur utilisateur = utilisateurRep.findByLogin(authentication.getName()).get();
			
			return bibliothequeRep.getBibliothequesCotisation(utilisateur.getId());
		}
		
		public String cotise(long id) {
			Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
			Utilisateur utilisateur = utilisateurRep.findByLogin(authentication.getName()).get();
			Bibliotheque bibliotheque = bibliothequeRep.getBibliotheque(id);
			
			//if(pay())
			Cotisation cotisation = new Cotisation(new Date(), utilisateur, bibliotheque);
			cotisationRep.save(cotisation);
			return "Cotisation effectuée";
		}
		
}
