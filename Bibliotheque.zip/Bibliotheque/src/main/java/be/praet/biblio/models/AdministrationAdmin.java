package be.praet.biblio.models;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="administrationadmin")
public class AdministrationAdmin {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id", nullable=false)
	private long id;
	@Column(name="date", nullable=false)
	private Date date;
	@Column(name="action", nullable=false)
	private String action;
	@Column(name="raison", nullable=false)
	private String raison;
	@ManyToOne
	@JoinColumn(name="idadministrateurcible")
	private Administrateur administrateurCible;
	@ManyToOne
	@JoinColumn(name="idadministrateur")
	private Administrateur administrateur;
	
	public AdministrationAdmin() {
		super();
	}

	public AdministrationAdmin(Date date, String action, String raison, Administrateur administrateurCible,
			Administrateur administrateur) {
		super();
		this.date = date;
		this.action = action;
		this.raison = raison;
		this.administrateurCible = administrateurCible;
		this.administrateur = administrateur;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getRaison() {
		return raison;
	}

	public void setRaison(String raison) {
		this.raison = raison;
	}

	public Administrateur getAdministrateurCible() {
		return administrateurCible;
	}

	public void setAdministrateurCible(Administrateur administrateurCible) {
		this.administrateurCible = administrateurCible;
	}

	public Administrateur getAdministrateur() {
		return administrateur;
	}

	public void setAdministrateur(Administrateur administrateur) {
		this.administrateur = administrateur;
	}
	
}
