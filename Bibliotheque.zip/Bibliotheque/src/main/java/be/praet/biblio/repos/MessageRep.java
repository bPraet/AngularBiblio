package be.praet.biblio.repos;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import be.praet.biblio.models.Message;

public interface MessageRep extends CrudRepository<Message, Long>{

	@Query(value="SELECT * FROM communication WHERE idAdministrateur = ?1", nativeQuery=true)
	List<Message> getMessages(long id);
	
	@Query(value="SELECT * FROM communication WHERE idAdministrateur = ?1 AND id = ?2", nativeQuery=true)
	Message getMessage(long idAdmin, long id);
	
	@Query(value="SELECT * FROM communication WHERE idUtilisateur = ?1", nativeQuery=true)
	List<Message> getMessagesUser(long id);
	
	@Query(value="SELECT * FROM communication WHERE idUtilisateur = ?1 AND id = ?2", nativeQuery=true)
	Message getMessageUser(long idUser, long id);
}
