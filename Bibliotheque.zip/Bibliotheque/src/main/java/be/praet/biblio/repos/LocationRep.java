package be.praet.biblio.repos;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import be.praet.biblio.models.Location;

public interface LocationRep extends CrudRepository<Location, Long> {
	@Query(value="SELECT TOP 1 idExemplaire, dateFin, DATEDIFF(day, GETDATE(), dateFin) FROM location\n" + 
			"WHERE DATEDIFF(day, GETDATE(), dateFin) > 0\n" + 
			"ORDER BY dateFin ASC", nativeQuery=true)
	public Date getLastDateRetourByIdExemplaire(long idExemplaire);
	
	@Query(value="SELECT * FROM location WHERE idUtilisateur = ?1", nativeQuery=true)
	public List<Location> getLocations(long id);
	
	@Query(value="SELECT * FROM location", nativeQuery=true)
	public List<Location> getLocationsAdmin();
	
	@Query(value="SELECT location.* FROM location\n" + 
			"INNER JOIN exemplaire ON location.idExemplaire = exemplaire.id\n" + 
			"INNER JOIN bibliotheque ON exemplaire.idBibliotheque = bibliotheque.id\n" + 
			"INNER JOIN responsable ON bibliotheque.id = responsable.idBibliotheque\n" + 
			"WHERE responsable.idAdministrateur = ?1", nativeQuery=true)
	public List<Location> getLocationsAdmin(long id);
	
	@Query(value="SELECT CAST(COUNT(1) AS BIT) FROM location\n" + 
			"INNER JOIN exemplaire ON location.idExemplaire = exemplaire.id\n" + 
			"INNER JOIN bibliotheque ON exemplaire.idBibliotheque = bibliotheque.id\n" + 
			"INNER JOIN responsable ON bibliotheque.id = responsable.idBibliotheque\n" + 
			"WHERE responsable.idAdministrateur = ?1 AND location.id = ?2", nativeQuery=true)
	public boolean isAdminLocation(long idAdmin, long idLocation);
}
