package be.praet.biblio.repos;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import be.praet.biblio.models.Amende;

public interface AmendeRep extends CrudRepository<Amende, Long>{
	@Query(value="SELECT * FROM amende WHERE idUtilisateur = ?1 AND paye != 1", nativeQuery=true)
	List<Amende> getUnpaidAmendeById(long id);
	
	@Query(value="SELECT * FROM amende WHERE idUtilisateur = ?1", nativeQuery=true)
	List<Amende> getAmendeByUserId(long id);
}
