package be.praet.biblio.controllers;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import be.praet.biblio.models.Livre;
import be.praet.biblio.services.BibliothequeService;
import be.praet.biblio.services.LivreService;
import be.praet.biblio.viewModels.ExemplaireRetour;

@RestController
public class LivreController {
	
	@Autowired
	private BibliothequeService bibliServ;
	@Autowired
	private LivreService livreServ;
	
	@GetMapping("/livres")
	public Map<Boolean, List<Livre>> catalogue() {
		return bibliServ.getLivresForUtilisateur();
	}
	
	@GetMapping("/livre/{id}")
	public Map<String, List<ExemplaireRetour>> livre(@PathVariable long id) {
		return bibliServ.getLivreForUtilisateur(id);
	}
	
	@PostMapping("/livre/{id}/setAvis")
	public String setAvis(@PathVariable long id, @RequestParam String note, @RequestParam String commentaire) {
		return livreServ.setAvis(note, commentaire, id);
	}
	
}
 