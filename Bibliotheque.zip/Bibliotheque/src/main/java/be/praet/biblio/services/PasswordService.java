package be.praet.biblio.services;

import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.stereotype.Service;

@Service
public class PasswordService {

	public String hash(String mdp) {
		return BCrypt.hashpw(mdp, BCrypt.gensalt(12));
	}
}
