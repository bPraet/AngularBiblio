package be.praet.biblio.repos;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import be.praet.biblio.models.Livre;

public interface LivreRep extends CrudRepository<Livre, Long>{
	
	@Query(value="SELECT DISTINCT livre.* FROM livre\n" + 
			"INNER JOIN exemplaire ON livre.id = exemplaire.idLivre\n" + 
			"INNER JOIN bibliotheque ON exemplaire.idBibliotheque = bibliotheque.id\n" + 
			"INNER JOIN cotisation ON bibliotheque.id = cotisation.idBibliotheque\n" + 
			"WHERE idUtilisateur = ?1 AND GETDATE() <= DATEADD(year, 1, cotisation.date)", nativeQuery=true)
	public List<Livre> findAllBookWhereUserSubscribed(long userId); //Livres louable dans une bibliotheque dont l'utilisateur a une cotisation
	
	@Query(value="SELECT * FROM livre WHERE id NOT IN(\n" + 
			"    SELECT DISTINCT livre.id FROM livre\n" + 
			"    INNER JOIN exemplaire ON livre.id = exemplaire.idLivre\n" + 
			"    INNER JOIN bibliotheque ON exemplaire.idBibliotheque = bibliotheque.id\n" + 
			"    INNER JOIN cotisation ON bibliotheque.id = cotisation.idBibliotheque\n" + 
			"    WHERE idUtilisateur = ?1 AND GETDATE() <= DATEADD(year, 1, cotisation.date)\n" + 
			")", nativeQuery=true)
	public List<Livre> findAllBookWhereUserDidNotSubscribed(long userId); //Livres non louable dans une bibliotheque dont l'utilisateur a une cotisation
	
	@Modifying
	@Transactional
	@Query(value="UPDATE livre SET nom = ?1, EAN = ?2, ISBN = ?3, edition = ?4, auteur = ?5, prix = ?6, synopsis = ?7, numerique = ?8\n" + 
			"WHERE id = ?9", nativeQuery=true)
	public void updateBook(String nom, String EAN, String ISBN, String edition, String auteur, float prix, 
			String synopsis, boolean numerique, long id);
}
